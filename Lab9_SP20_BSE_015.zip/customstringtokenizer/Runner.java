package customstringtokenizer;
import java.util.StringTokenizer;

public class Runner {
        public static void main(String[] args) {
        StringTokenizer s1 = new StringTokenizer("There are 2 students in this class");
        StringTokenizer s2 = new StringTokenizer("There are two students in this class");
        int count = countTokens(s1);
        System.out.println("Total number of Tokens in string 1: "+ count);
        count = countTokens(s2);
        System.out.println("Total number of Tokens in string 2: "+ count);
        }
}