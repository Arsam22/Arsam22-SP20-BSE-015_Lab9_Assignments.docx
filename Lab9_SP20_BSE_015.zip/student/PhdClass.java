package student;
//PhdStudent class that is the child class of Student class
    class PhdStudent extends Student{
    @Override
    public void takeXam(){
        System.out.println("Giving Final Defense Presentation!");
    }
}