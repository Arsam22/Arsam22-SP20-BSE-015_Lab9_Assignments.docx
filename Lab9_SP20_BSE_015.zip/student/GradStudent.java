package student;
//GradStudent class that is the child class of Student class
    class GradStudent extends Student{
    @Override
    public void takeXam(){
        System.out.println("Giving Written paper!");
    }
}