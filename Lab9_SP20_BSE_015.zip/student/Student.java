package student;
abstract class Student {
    public void takeXam(){
        System.out.println("Taking Xam!");
    }
}