package clock;
public class Clock {
    String hours, minutes, seconds;
    public Clock(String hours, String minutes, String seconds){
        this.hours = hours;
        this.minutes = minutes;
        this.seconds = seconds;
    }
    public void display(){
        System.out.println(this.hours + ":" + this.minutes + ":" + this.seconds);
    }
}
class ChildClock extends Clock{
    public ChildClock(String hours, String minutes, String seconds){
        super(hours, minutes, seconds);
    }
    @Override
    public void display(){
        System.out.println("24 Hour Format:");
        super.display();
        System.out.println("AM/PM Hour Format:");
        int hour1 = (int)hours.charAt(0) - '0';
        int hour2 = (int)hours.charAt(1)- '0';
        int tothour = hour1 * 10 + hour2;
        String m;
        if(tothour < 12)
            m="AM";
        else
            m="PM";
        tothour %= 12;
        if (tothour == 0) {
            System.out.print("AM/PM");
            System.out.print(":" + minutes + ":" + seconds);
        }
        else{
            System.out.print(tothour);
            System.out.print(":" + minutes + ":" + seconds);
        }
        System.out.println(" "+m);
    }
}