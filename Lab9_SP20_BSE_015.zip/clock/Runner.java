package clock;
public class Runner {
        public static void main(String[] args) {
            ChildClock time=new ChildClock("13","24","54");
            time.display();
        }
}